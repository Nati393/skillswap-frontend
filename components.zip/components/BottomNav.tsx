'use client';

import { useRouter, usePathname } from 'next/navigation';

export function BottomNav({ session }: { session: any }) {
  const router = useRouter();
  const pathname = usePathname();
  const items = [
    { icon: '🏠', label: 'Inicio', path: '/feed' },
    { icon: '🔍', label: 'Explorar', path: '/explore' },
    { icon: '📅', label: 'Agenda', path: '/agenda' },
    { icon: '💬', label: 'Comunidad', path: '/messages' },
    { icon: '👤', label: 'Perfil', path: `/profile/${session?._id}` },
  ];
  return (
    <nav style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#fff', borderTop: '1px solid #f1f5f9', padding: '6px 0 16px', zIndex: 50 }}>
      <div style={{ maxWidth: 520, margin: '0 auto', display: 'flex', justifyContent: 'space-around' }}>
        {items.map((item) => {
          const isActive =
            pathname === item.path ||
            (item.path !== '/feed' && item.path !== `/profile/${session?._id}` && pathname.startsWith(item.path)) ||
            (item.path === `/profile/${session?._id}` && pathname === `/profile/${session?._id}`);
          return (
            <button key={item.label} onClick={() => router.push(item.path)}
              style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, background: 'none', border: 'none', cursor: 'pointer', padding: '4px 8px' }}>
              <div style={{ width: 40, height: 40, borderRadius: 12, background: isActive ? 'linear-gradient(135deg,#4f46e5,#7c3aed)' : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 19, transition: 'all 0.18s' }}>
                {item.icon}
              </div>
              <span style={{ fontSize: 10, fontWeight: isActive ? 700 : 500, color: isActive ? '#4f46e5' : '#94a3b8' }}>{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}